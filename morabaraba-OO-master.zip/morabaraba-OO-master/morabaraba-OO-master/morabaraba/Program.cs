﻿using System;
using System.Collections.Generic;

namespace morabaraba
{
    class Program
    {
        static void Main(string[] args)
        {
            Board gameBoard = new Board();
            Console.WriteLine(gameBoard.drawBoard());

            GameManager manageGame = new GameManager();
            //Player x = new Player();
            string currentPlayer = "X";
            manageGame.Play(currentPlayer);

            Console.ReadLine();
        }
        class Board
        {
            public Board()
            {
                //The constructor
            }
            public List<string> GameBoard = new List<string>
              {    "a1", "a4","a7",
                   "b2","b4","b6",
                   "c3", "c4", "c5",
                   "d1", "d2", "d3",
                   "d5", "d6","d7",
                   "e3","e4","e5",
                   "f2","f4", "f6",
                   "g1", "g4","g7"
               };

            public string drawBoard()
            {

                return
              $@"
                    1   2   3   4   5   6   7
                A   {GameBoard[0]}-----------{GameBoard[1]}-----------{GameBoard[2]}
                    | \         |         / |
                B   |   {GameBoard[3]}-------{GameBoard[4]}-------{GameBoard[5]}   |
                    |   | \     |     / |   |
                C   |   |   {GameBoard[6]}---{GameBoard[7]}----{GameBoard[8]}   |  |
                    |   |   |       |   |   |
                D  {GameBoard[9]}---{GameBoard[10]}---{GameBoard[11]}        {GameBoard[12]}--{GameBoard[13]}--{GameBoard[14]}
                    |   |   |       |   |   |
                E   |   |   {GameBoard[15]}---{GameBoard[16]}---{GameBoard[17]}       |
                    |   | /     |     \ |   |
                F   |   {GameBoard[18]}-------{GameBoard[19]}-------{GameBoard[20]}   |
                    | /         |         \ |
                G   {GameBoard[21]}-----------{GameBoard[22]}-----------{GameBoard[23]}
            ";
            }
            public bool MakeMove(string player, string position)
            {
                for (int i = 0; i < GameBoard.Count; i++)
                {
                    if (GameBoard[i] == position)
                    {
                        GameBoard[i] = player;
                        return true;
                    }

                }//else, the value enterd by the player is an invalid move or is currently occupied

                return false;
            }
        }
        class Player
        {

            public int numCows = 12;
            public Player()
            {
                //This is the constructor for the Player
            }

            public string switchPlayer(string player)
            {
                string ans = player == "X" ? "O" : "X";
                return ans;
            }

        }
        class GameManager
        {
            Board newBoard = new Board();
            Player N = new Player();



            public GameManager()
            {
                //The constructor for GameManager
                IsDraw();
                //Play();
                Winner();
            }


            private void IsDraw()
            {
            }
            public void Play(string player)
            {
                Console.WriteLine("{0}'s turn: PLAYER {1}, Enter cell reference of position to place your move:", player, player);
                string positon = Console.ReadLine();
                if (newBoard.MakeMove(player, positon) == true)
                {

                    Console.Clear();
                    Console.WriteLine(newBoard.drawBoard());

                    Play(N.switchPlayer(player));
                }

                Console.Clear();
                Console.WriteLine(newBoard.drawBoard());
                Console.WriteLine("The position you have entered is invalid; It may be currently occupied or you may have entered an invalid cell reference");
                Console.Clear();
                Play(player);


            }
            private void Winner()
            {
            }
        }
    }

    public interface IBoard
    {
        ICow Occupant(string position);
        IEnumerable<string> Cows(Cow cow); // stores the cows 
        void PlaceCow(ICow cow, string position); // places the cow on the board
        void RemoveCapturedCow(); // removes the shot cow
        void MillFormed(ICow cow);
        void CheckPreviousMill(IMills Mill);
    }
    public enum Cow { X, O } // either X cow or O cow
    public enum Status { Captured, Active, NotPlaced }

    public interface IMills
    {
        IEnumerable<string> Mills(IBoard board);
        bool MillFormed(IBoard board);
    }

    public interface ICow
    {
        IEnumerable<string> NormalMoves(IBoard board);
        IEnumerable<string> MillForms(IBoard board);
        Status Status { get; }
        Cow Cow { get; }
        string position { get; }
        void Move(string destination);
        void Shoot(string destination);
        void Fly(string destination);
        void Place(string destination);
    }
    public interface IPlayer
    {
        string Name { get; }
        (int,int) getMove();
    }
    public interface IReferee
    {
        IPlayer Winner();
        bool IsDraw();
        void Play();
    }
    public class illegalMoveException : ApplicationException { }
    public class Board : IBoard
    {
        public void CheckPreviousMill(IMills Mill)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> Cows(Cow cow)
        {
            throw new NotImplementedException();
        }

        public void MillFormed(ICow cow)
        {
            throw new NotImplementedException();
        }

        public ICow Occupant(string position)
        {
            throw new NotImplementedException();
        }

        public void PlaceCow(ICow cow, string position)
        {
            throw new NotImplementedException();
        }

        public void RemoveCapturedCow()
        {
            throw new NotImplementedException();
        }
    }
    public class Player : IPlayer
    {
        public string Name => throw new NotImplementedException();

        public (int, int) getMove()
        {
            throw new NotImplementedException();
        }
    }
    public class Cows : ICow
    {
        public Status Status => throw new NotImplementedException();

        public string position => throw new NotImplementedException();

        Cow ICow.Cow => throw new NotImplementedException();

        public void Fly(string destination)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> MillForms(IBoard board)
        {
            throw new NotImplementedException();
        }

        public void Move(string destination)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> NormalMoves(IBoard board)
        {
            throw new NotImplementedException();
        }

        public void Place(string destination)
        {
            throw new NotImplementedException();
        }

        public void Shoot(string destination)
        {
            throw new NotImplementedException();
        }
    }
    public class Referee : IReferee
    {
        public bool IsDraw()
        {
            throw new NotImplementedException();
        }

        public void Play()
        {
            throw new NotImplementedException();
        }

        public IPlayer Winner()
        {
            throw new NotImplementedException();
        }
    }
    public class Mill : IMills
    {
        public bool MillFormed(IBoard board)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> Mills(IBoard board)
        {
            throw new NotImplementedException();
        }
    }
}
