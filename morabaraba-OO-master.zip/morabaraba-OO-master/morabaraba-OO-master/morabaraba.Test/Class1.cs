﻿using System;

namespace morabaraba.Test
{
    public class Class1
    {
    }
}
